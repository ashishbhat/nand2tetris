rm -rf *.class
