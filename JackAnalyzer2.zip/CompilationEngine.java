import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;

public class CompilationEngine {
	public static final String CONSTANT_SEGMENT = "constant";

	private enum ClassVarDecState {
		START, QUALIFIER, TYPE, IDENTIFIER, CLOSE, TERMINATE;
	}

	private JackTokenizer tknzr;
	private Path sourcePath;
	private StringBuilder compiledCode = new StringBuilder();
	private SymbolTable classTable;
	private SymbolTable subRoutineTable;
	private String className;
	private static int labelCount = 0;
	VMWriter vmWriter = new VMWriter();

	public CompilationEngine(Path sourcePath) {
		super();
		this.sourcePath = sourcePath;
		this.className = sourcePath.getFileName().toString().split("\\.")[0];
		this.classTable = new SymbolTable();
		this.subRoutineTable = new SymbolTable();
		tknzr = new JackTokenizer(sourcePath);
	}

	public void compile() throws IOException {
		compileClass();
		String outFile = sourcePath.getParent().toString() + "/" + this.className + ".xml";
		FileWriter f = new FileWriter(outFile);
		f.write(compiledCode.toString());
		f.close();
		// System.out.print(compiledCode);
	}

	private void compileClass() {
		String token = null;
		String tokenType = null;
		compiledCode.append("<class>\n");
		tknzr.advance();
		process("class");
		token = tknzr.token();
		tokenType = tknzr.tokenType();
		if (tokenType.equals(LexicalElements.IDENTIFIER)) {
			printXMLToken(token);
		} else {
			throw new IllegalArgumentException("Compilation Error. Unexpected Token: " + token);
		}
		tknzr.advance();
		process("{");
		compileClassVarDec();
		compileSubroutine();
		process("}");
		compiledCode.append("</class>\n");
		vmWriter.close();
	}

	private void compileClassVarDec() {
		ClassVarDecState state = ClassVarDecState.START;
		String token = tknzr.token();
		SymbolTable.Kind kind = SymbolTable.Kind.NONE;
		String type = "";
		String name = "";
		while (true) {
			switch (state) {
			case START:
				if (token.equals(LexicalElements.STATIC) || token.equals(LexicalElements.FIELD)) {
					if (token.equals(LexicalElements.STATIC)) {
						kind = SymbolTable.Kind.STATIC;
					} else {
						kind = SymbolTable.Kind.FIELD;
					}
					compiledCode.append("<classVarDec>\n");
					printXMLToken(token);
					state = ClassVarDecState.QUALIFIER;
					tknzr.advance();
				} else {
					if (token.equals(LexicalElements.METHOD) || token.equals(LexicalElements.FUNCTION)
							|| token.equals(LexicalElements.CONSTRUCTOR) || token.equals("}")) {
						state = ClassVarDecState.TERMINATE;
					} else {
						throw new IllegalArgumentException(
								"Compilation Error. class var declaration must start with static or field.");
					}

				}
				break;
			case QUALIFIER:
				type = processType();
				state = ClassVarDecState.TYPE;
				break;
			case TYPE:
				token = tknzr.token();
				if (!tknzr.tokenType().equals(LexicalElements.IDENTIFIER)) {
					throw new IllegalArgumentException("Compilation Error. Unexpected Token: " + token);
				} else {
					name = token;
					classTable.define(name, type, kind);
					printXMLToken(token);
					state = ClassVarDecState.IDENTIFIER;
					tknzr.advance();
				}
				break;
			case IDENTIFIER:
				token = tknzr.token();
				try {
					process(",");
					state = ClassVarDecState.TYPE;
				} catch (Exception ex) {
					if (token.equals(";")) {
						state = ClassVarDecState.CLOSE;
					} else {
						throw new IllegalArgumentException("Compilation Error. Illegal Statement. Missing ;");
					}
				}
				break;
			case CLOSE:
				printXMLToken(token);
				compiledCode.append("</classVarDec>\n");
				tknzr.advance();
				compileClassVarDec();
				state = ClassVarDecState.TERMINATE;
			case TERMINATE:
				return;
			default:
				throw new IllegalArgumentException("Compilation Error. Illegal Statement");
			}
		}
	}

	private void compileSubroutine() {
		subRoutineTable.reset();
		String subRoutineName = "";
		String token = tknzr.token();
		if (!token.equals(LexicalElements.METHOD) && !token.equals(LexicalElements.FUNCTION)
				&& !token.equals(LexicalElements.CONSTRUCTOR)) {
			return;
		} else {
			compiledCode.append("<subroutineDec>\n");
			printXMLToken(token);
		}
		processReturnType();
		tknzr.advance();
		token = tknzr.token();
		subRoutineName = this.className + "." + token;
		if (!tknzr.tokenType().equals(LexicalElements.IDENTIFIER)) {
			throw new IllegalArgumentException("Compilation Error. Unexpected Token: " + token);
		}
		tknzr.advance();
		process("(");
		compiledCode.append("<parameterList>\n");
		compileParameterList();
		compiledCode.append("</parameterList>\n");
		process(")");
		compileSubroutineBody(subRoutineName);
		compiledCode.append("</subroutineDec>\n");
		compileSubroutine();
	}

	private void compileParameterList() {
		String token = tknzr.token();
		String type = "";
		String name = "";
		while (!token.equals(")")) {
			type = token;
			processType();

			////
			if (!tknzr.tokenType().equals(LexicalElements.IDENTIFIER)) {
				throw new IllegalArgumentException("Compilation Error. Unexpected Token: " + token);
			} else {
				name = token;
				subRoutineTable.define(name, type, SymbolTable.Kind.ARG);
				token = tknzr.token();
				printXMLToken(token);
				tknzr.advance();
				token = tknzr.token();
			}
			///
			try {
				process(",");
			} catch (Exception ex) {
				if (token.equals(")")) {
					continue;
				} else {
					throw new IllegalArgumentException("Compilation Error. Missing ',' separator in parameterList");
				}
			}
			token = tknzr.token();
		}
	}

	private void compileSubroutineBody(String subRoutineName) {
		compiledCode.append("<subroutineBody>\n");

		process("{");
		compileVarDec();
		vmWriter.writeFunction(subRoutineName, subRoutineTable.varCount(SymbolTable.Kind.VAR));
		compiledCode.append("<statements>\n");
		compileStatements();
		compiledCode.append("</statements>\n");
		process("}");

		compiledCode.append("</subroutineBody>\n");

	}

	private void compileVarDec() {
		String type = "";
		String name = "";
		if (!tknzr.token().equals("var")) {
			return;
		}
		compiledCode.append("<varDec>\n");
		process("var");
		if (!LexicalElements.builtinTypes.contains(tknzr.token())
				&& !tknzr.tokenType().equals(LexicalElements.IDENTIFIER)) {
			throw new IllegalArgumentException("Compilation Error. Invalid type for subRoutine variable declaration.");
		}
		type = processType();
		String token = tknzr.token();
		while (!token.equals(";")) {
			if (!tknzr.tokenType().equals(LexicalElements.IDENTIFIER)) {
				throw new IllegalArgumentException("Compilation Error. Unexpected Token: " + token);
			} else {
				name = token;
				subRoutineTable.define(name, type, SymbolTable.Kind.VAR);
				token = tknzr.token();
				printXMLToken(token);
				tknzr.advance();
				token = tknzr.token();
			}
			try {
				process(",");
			} catch (Exception ex) {
				if (token.equals(";")) {
					continue;
				} else {
					throw new IllegalArgumentException("Compilation Error. Illegal Statement");
				}
			}
			token = tknzr.token();
		}
		printXMLToken(token);
		compiledCode.append("</varDec>\n");
		tknzr.advance();
		compileVarDec();
	}

	private void compileStatements() {
		if (LexicalElements.statementTypes.contains(tknzr.token())) {
			String stmt = tknzr.token();
			switch (stmt) {
			case LexicalElements.LET:
				compileLetStatement();
				break;
			case LexicalElements.DO:
				compileDoStatement();
				break;
			case LexicalElements.RETURN:
				compileReturnStatement();
				break;
			case LexicalElements.WHILE:
				compileWhileStatement();
				break;
			case LexicalElements.IF:
				compileIfStatement();
				break;
			}
		} else {
			return;
		}
		compileStatements();
	}

	private void compileLetStatement() {
		process("let");
		if (!tknzr.tokenType().equals(LexicalElements.IDENTIFIER)) {
			throw new IllegalArgumentException("Compilation Error. Unexpected Token: " + tknzr.token());
		} else {
			String token = tknzr.token();
			tknzr.advance();
			if (tknzr.token().equals("[")) {
				process("[");
				compileExpression();
				process("]");
				process("=");
				compileExpression();
				process(";");
			} else {
				SymbolTable table = null;
				if (subRoutineTable.isPresent(token)) {
					table = subRoutineTable;
				} else if (classTable.isPresent(token)) {
					table = classTable;
				} else {
					throw new IllegalArgumentException("Invalid symbol " + token);
				}
				process("=");
				compileExpression();
				vmWriter.writePop(table.getSegment(token), table.indexOf(token));
				process(";");
			}
		}

	}

	private void compileDoStatement() {
		compiledCode.append("<doStatement>\n");
		process("do");
		compileExpression();
		vmWriter.writePop("temp", 0);
		process(";");
		compiledCode.append("</doStatement>\n");
	}

	private void compileReturnStatement() {
		compiledCode.append("<returnStatement>\n");
		process(LexicalElements.RETURN);
		if (!tknzr.token().equals(";")) {
			compiledCode.append("<expression>\n");
			compileExpression();
			compiledCode.append("</expression>\n");
		} else {
			vmWriter.writePush(CONSTANT_SEGMENT, 0);
		}
		vmWriter.writeReturn();
		process(";");
		compiledCode.append("</returnStatement>\n");
	}

	private void compileWhileStatement() {
		String label0 = getLabelName();
		String label1 = getLabelName();

		vmWriter.writeLabel(label0);
		compiledCode.append("<whileStatement>\n");
		process(LexicalElements.WHILE);
		process("(");
		compiledCode.append("<expression>\n");
		compileExpression();
		vmWriter.writeAirthmetic("neg");
		vmWriter.writeAirthmetic("not");
		vmWriter.writeIf(label1);
		compiledCode.append("</expression>\n");
		process(")");
		process("{");
		compiledCode.append("<statements>\n");
		compileStatements();
		vmWriter.writeGoto(label0);
		vmWriter.writeLabel(label1);
		compiledCode.append("</statements>\n");
		process("}");
		compiledCode.append("</whileStatement>\n");
	}

	private void compileIfStatement() {
		compiledCode.append("<ifStatement>\n");
		process(LexicalElements.IF);
		process("(");
		compiledCode.append("<expression>\n");
		compileExpression();
		compiledCode.append("</expression>\n");
		process(")");
		process("{");
		compiledCode.append("<statements>\n");
		compileStatements();
		compiledCode.append("</statements>\n");
		process("}");
		// optional elsee part
		if (tknzr.token().equals(LexicalElements.ELSE)) {
			process(LexicalElements.ELSE);
			process("{");
			compiledCode.append("<statements>\n");
			compileStatements();
			compiledCode.append("</statements>\n");
			process("}");
		}
		compiledCode.append("</ifStatement>\n");
	}

	private void compileTerm() {
		if (!tknzr.tokenType().equals(LexicalElements.IDENTIFIER) && !tknzr.token().equals("(")
				&& !LexicalElements.keyWordConstants.contains(tknzr.token())
				&& tknzr.tokenType() != LexicalElements.INT_CONST && tknzr.tokenType() != LexicalElements.STRING_CONST
				&& !LexicalElements.unaryOps.contains(tknzr.token())) {
			throw new IllegalArgumentException("Compilation Error. Unexpected Token: " + tknzr.token());
		} else {
			compiledCode.append("<term>\n");
			if (LexicalElements.unaryOps.contains(tknzr.token())) {
				String op = tknzr.token();
				process(tknzr.token());
				compileTerm();
				vmWriter.writeAirthmetic(getUnaryOpCommand(op));
			} else if (tknzr.tokenType() == LexicalElements.IDENTIFIER) {
				String currentToken = tknzr.token();
				// printXMLToken(currentToken);
				tknzr.advance();
				if (tknzr.token().equals("[")) {
					process("[");
					compiledCode.append("<expression>\n");
					compileExpression();
					compiledCode.append("</expression>\n");
					process("]");
				}

				else if (tknzr.token().equals("(")) {
					if (tknzr.token().equals("(")) {
						process("(");
						compiledCode.append("<expressionList>\n");
						if (!tknzr.token().equals(")")) {
							int nArgs = compileExpressionList(0);
							vmWriter.writeCall(currentToken, nArgs);

						}
						compiledCode.append("</expressionList>\n");
						process(")");
					}

				} else if (tknzr.token().equals(".")) {
					process(".");
					if (!tknzr.tokenType().equals(LexicalElements.IDENTIFIER)) {
						throw new IllegalArgumentException("Compilation Error. Unexpected Token: " + tknzr.token());
					} else {
						String subRoutineName = currentToken + "." + tknzr.token();
						process(tknzr.token());
						process("(");
						compiledCode.append("<expressionList>\n");
						if (!tknzr.token().equals(")")) {
							int nArgs = compileExpressionList(0);
							vmWriter.writeCall(subRoutineName, nArgs);
						}
						compiledCode.append("</expressionList>\n");
						process(")");
					}
				} else {
					SymbolTable table = null;
					if (subRoutineTable.isPresent(currentToken)) {
						table = subRoutineTable;
					} else if (classTable.isPresent(currentToken)) {
						table = classTable;
					} else {
						throw new IllegalArgumentException("Invalid symbol: " + currentToken);
					}
					vmWriter.writePush(table.getSegment(currentToken), table.indexOf(currentToken));
				}
			} else if (tknzr.token().equals("(")) {
				process(tknzr.token());
				compiledCode.append("<expression>\n");
				compileExpression();
				compiledCode.append("</expression>\n");
				process(")");
			} else {
				if (tknzr.tokenType() == LexicalElements.INT_CONST)
					vmWriter.writePush(CONSTANT_SEGMENT, Integer.parseInt(tknzr.token()));
				else if (tknzr.tokenType() == LexicalElements.STRING_CONST) {
					vmWriter.writePush(CONSTANT_SEGMENT, tknzr.token().length() - 2);
					vmWriter.writeCall("String.new", 1);
					for (char x : tknzr.token().substring(1, tknzr.token().length() - 1).toCharArray()) {
						vmWriter.writePush(CONSTANT_SEGMENT, (int) x);
						vmWriter.writeCall("String.appendChar", 2);
					}
				}

				tknzr.advance();
			}
			compiledCode.append("</term>\n");
		}
	}

	private void compileExpression() {
		compileTerm();
		String token = tknzr.token();
		if (LexicalElements.Ops.contains(token)) {
			process(tknzr.token());
			compileTerm();
			vmWriter.writeAirthmetic(getOpCommand(token));
		}
	}

	private int compileExpressionList(int count) {
		compiledCode.append("<expression>\n");
		compileExpression();
		++count;
		compiledCode.append("</expression>\n");
		if (tknzr.token().equals(",")) {
			process(",");
			count = compileExpressionList(count);
		}
		return count;
	}

	private void process(String token) {
		if (token.equals(tknzr.token())) {
			// printXMLToken(tknzr.token());
			tknzr.advance();
		} else {
			throw new IllegalArgumentException("Compilation Error. Missing Token: " + token);
		}

	}

	private String processType() {
		String token = tknzr.token();
		if (!token.equals(LexicalElements.INT) && !token.equals(LexicalElements.CHAR)
				&& !token.equals(LexicalElements.BOOLEAN) && !tknzr.tokenType().equals(LexicalElements.IDENTIFIER)) {
			throw new IllegalArgumentException("Compilation Error. Unexpected Token: " + token);
		} else {
			printXMLToken(token);
			tknzr.advance();
		}
		return token;
	}

	private void processReturnType() {
		tknzr.advance();
		String token = tknzr.token();
		if (!token.equals(LexicalElements.INT) && !token.equals(LexicalElements.CHAR)
				&& !token.equals(LexicalElements.VOID) && !token.equals(LexicalElements.BOOLEAN)
				&& !tknzr.tokenType().equals(LexicalElements.IDENTIFIER)) {
			throw new IllegalArgumentException("Compilation Error. Unexpected Token: " + token);
		} else {
			printXMLToken(token);
		}
	}

	private void printXMLToken(String token) {
		String tokenType = tknzr.tokenType();
		switch (tokenType) {
		case LexicalElements.KEYWORD:
			compiledCode.append("<keyword> " + token + " </keyword>\n");
			break;
		case LexicalElements.IDENTIFIER:
			compiledCode.append("<identifier> " + token + " </identifier>\n");
			break;
		case LexicalElements.INT_CONST:
			compiledCode.append("<integerConstant> " + token + " </integerConstant>\n");
			break;
		case LexicalElements.STRING_CONST:
			compiledCode.append("<stringConstant> " + tknzr.stringVal(token) + " </stringConstant>\n");
			break;
		case LexicalElements.SYMBOL:
			compiledCode.append("<symbol> " + tknzr.symbol(token) + " </symbol>\n");
			break;
		}

	}

	private String getOpCommand(String op) {
		switch (op) {
		case "+":
			return "add";
		case "-":
			return "sub";
		case "=":
			return "eq";
		case "<":
			return "lt";
		case ">":
			return "gt";
		case "&":
			return "and";
		case "|":
			return "and";
		case "~":
			return "not";
		case "*":
			return new String("call Math.multiply 2");
		case "/":
			return new String("call Math.divide 2");
		default:
			return null;
		}
	}

	private String getUnaryOpCommand(String op) {
		switch (op) {
		case "-":
			return "neg";
		case "~":
			return "not";
		default:
			return null;
		}
	}

	private String getLabelName() {
		return className + "_" + labelCount++;
	}

}
