
public class VMWriter {
	private StringBuilder vmCode = new StringBuilder();
	private final String ENDLINE = "\n";

	public void writeFunction(String name, int nVars) {
		vmCode.append("function " + name + " " + nVars);
		vmCode.append(ENDLINE);
	}

	public void writeReturn() {
		vmCode.append("return");
		vmCode.append(ENDLINE);
	}

	public void writeCall(String name, int nArgs) {
		vmCode.append("call " + name + " " + nArgs);
		vmCode.append(ENDLINE);
	}

	public void writePush(String segment, int index) {
		vmCode.append("push " + segment + " " + index);
		vmCode.append(ENDLINE);
	}

	public void writePop(String segment, int index) {
		vmCode.append("pop " + segment + " " + index);
		vmCode.append(ENDLINE);
	}

	public void writeAirthmetic(String command) {
		vmCode.append(command);
		vmCode.append(ENDLINE);
	}

	public void writeLabel() {

	}

	public void writeGoto() {

	}

	public void writeIf() {

	}

	public void close() {
		System.out.println(vmCode.toString());
	}

}
